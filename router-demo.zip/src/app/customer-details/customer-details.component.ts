import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-customer-details',
  templateUrl: './customer-details.component.html',
  styleUrls: ['./customer-details.component.css']
})
export class CustomerDetailsComponent implements OnInit {

  public customerId = '';

  constructor(private route: ActivatedRoute) { 
    route.paramMap.subscribe(map => {
      this.customerId = map.get('id');
    });
  }

  ngOnInit() {
  }

}
